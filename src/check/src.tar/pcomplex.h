#ifndef __pcomplexh__
#define __pcomplexh__

#include "interp.h"
#include "input.h"

#define DEBUG_OFF	0
#define DEBUG_NO_V	1
#define DEBUG_NO_T	2

struct pcomplex
{
	int is_inside;
	int nsites;
	int nattach;
	int bound;
	int debug;

	// all masses.
	double *mass;

	// all WCA/LJ radii
	double *sigma;
	double *att_eps;
	double *att_sigma;

	// all coordinates in 3D
	double *rall;
	// attach coordinates in f/uv; can exceed face bounds
	int *fs;	
	double *puv;

	// in the final face bounds.
	int *grad_fs;	
	double *grad_puv;
	
	double *p_m1; // Hamiltonian conjugate momenta, previous time step
	double *qdot_m1; // time derivatives of generalized coordinates, previous time step

	double *p; // Hamiltonian conjugate momenta
	double *qdot; // time derivatives of generalized coordinates.
	double *save_grad;
	
	double *PBC_ext; // the current PBC vector of each site.
	double *last_pos;

	double *p_area;
	double *p_c0;

	double *coord_transform;

	virtual void alloc( void );
	virtual void pfree( void );

	virtual int getNBonds( void );
	virtual void putBonds( int *bond_list );

	virtual void init( surface *theSurface, double *, int f, double u, double v ); 
	virtual void init( double *r ); 

	virtual void bind( int f, double u, double v );
	virtual void unbind( void );

	virtual void applyParamsToComplex( double *p );
	virtual void getParamsFromComplex( double *p );
	virtual int nparams( void );
	virtual void orient( surface *theSurface, double *rsurf ) { }

	virtual void refresh( surface *theSurface, double *rsurf );
	virtual double V(surface *theSurface, double *rsurf);
	virtual double grad(surface *theSurface, double *rsurf, double *surface_g, double *particle_g ); 
	virtual void fd_grad_debug(surface *theSurface, double *rsurf ); 
	virtual void loadParams( parameterBlock *block );

	virtual void move_inside( void );
	virtual void move_outside( void );

	virtual int packLenF( void );
	virtual int packLenI( void );
	virtual void packageF( double * );
	virtual void unpackF( double * );
	virtual void packageI( int *);
	virtual void unpackI( int *); 
	
	virtual int isElastic(void) { return 0; }	

	void cacheVelocities( void );
	void prepareForGradient( void );
	void loadCoords( surface *theSurface, double *rsurf, double *r, double *n );
	void setrall( surface *theSurface, double *rsurf );
	void base_init( void );
	double T(void);
	double update_dH_dq( surface *theSurface, double *rsurf, double *Minv, double *mesh_grad, double *meshp, double *mesh_qdot, double *mesh_qdot0, double time_step=-1, double timestep_total=0 );
	void propagate_p( surface *theSurface, double *rsurf, double dt );
	void compute_qdot( surface *theSurface, double *rsurf, double *Minv, double *mesh_qdot0, double *mesh_qdot, double *meshp, double frac_mult=1.0 );
	void propagate_q( surface *theSurface, double *rsurf, double dt );

	void debug_dynamics( surface *theSurface,
		      double *rsurf,
		      double *Minv,
		
		      double *mesh_p,
		      double *mesh_qdot,
		      double *mesh_qdot0,

		      double *dV_dmesh, 
		      double *dT_dmesh,
		      double *dV_dcomplex,
		      double *dT_dcomplex );
	void debug_dPinv_dq( surface * theSurface, double *rsurf  );
	void getMeshQxdot( surface *theSurface, double *rsurf, double *Minv, double *mesh_p, double *mesh_qdot, double *mesh_qdot0, double *mesh_der_qdot );
	void applyLangevinFriction( surface * theSurface, double *rsurf, double dt, double gamma );
	void applyLangevinNoise( surface * theSurface, double *rsurf, double dt, double gamma, double temperature );
	int saveComplex( char *buffer, int *buflen, int bufLenMax );
	void saveComplex( FILE * theFile );
	void loadComplex( FILE * theFile, surface *theSurface, double *rsurf );
	double AttachV( surface *theSurface, double *rsurf );
	double AttachG( surface *theSurface, double *rsurf, double *gr, double *pg );
	void evaluate_momentum( surface *theSurface, double *rsurf, double *pout );
};

struct NBAR : pcomplex
{
	double bond_length;
	double k_phi;
	double k_theta;
	double bond_k;
	double theta_0;
	double phi_0;


	void init( surface *, double *rsurf, int f, double u, double v ); 
	void init( double *r );
	void bind( int f, double u, double v);
	void unbind( void );
	void loadParams( parameterBlock *block );
	void orient( surface *theSurface, double *rsurf );
	
	int getNBonds( void );
	void putBonds( int *bond_list );

	double V(surface *theSurface, double *rsurf);
	double grad( surface *theSurface, double *rsurf, double *surface_g, double *particle_g );

	void move_inside(void);
	void move_outside(void);	
};

struct dimer : pcomplex
{
	double bond_length;
	double bond_k;
	void init( surface *, double *rsurf, int f, double u, double v ); 
	void init( double *r );
	void loadParams( parameterBlock *block );
	
	int getNBonds( void );
	void putBonds( int *bond_list );
	
	 void bind( int f, double u, double v );
	 void unbind( void );

	virtual double V(surface *theSurface, double *rsurf);
	virtual double grad( surface *theSurface, double *rsurf, double *surface_g, double *particle_g );
};

struct MAB : dimer
{
	// dtheta_0 is the optimal angle between the normals, projected along the vector between the particles
	double dtheta_0;
	// k_theta is the force constant for dtheta_0.
	double k_theta;

	void move_inside( void );
	void move_outside( void );

	void loadParams( parameterBlock * block );
	virtual double V( surface *theSurface, double *rsurf );
	virtual double grad( surface *theSurface, double *rsurf, double *surface_g, double *particle_g );
};

struct elasticCrowder : pcomplex
{
	double hard_r;
	double d; // the distance from the surface to the sphere center.
	double bond_k;
	double att_eps_val;
	double att_sigma_val;

	void init( surface *, double *rsurf, int f, double u, double v ); 
	void loadParams( parameterBlock * block );
	int isElastic(void) { return 1; }	
	void move_inside( void );
	void move_outside( void );
	int getNBonds( void ) { return 2; }
	void putBonds( int *bond_list );
	virtual double V( surface *theSurface, double *rsurf );
	virtual double grad( surface *theSurface, double *rsurf, double *surface_g, double *particle_g );
};

#endif
