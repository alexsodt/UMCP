#ifndef __boundaryh__
#define __boundaryh__

struct boundary_condition
{
	double k[3];
	int cp;
	double ro[3];
};

#endif
