#include "gsl/gsl_randist.h"

void check_random_init( void );

#ifndef __gslrandomglobals__
extern gsl_rng *r_gen_global;
#endif
