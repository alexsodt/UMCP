#ifndef __npth__
#define __npth__

#define VOLUME_MOVE		0
#define CYL_TENSION_MOVE	1

#endif
