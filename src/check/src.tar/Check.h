#ifndef CHECK_H
#define CHECK_H

#include "Point.h"

struct Check {
	bool inside;
	Point direction;
};

#endif
