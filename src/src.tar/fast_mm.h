void fast_sub6_0( double *, double *);
void fast_sub6_1( double *, double *);
void fast_sub6_2( double *, double *);
void fast_sub6_3( double *, double *);
