#ifndef __unitsh__
#define __unitsh__

#define AMU_PER_KG (1.0/1.661e-27)
#define AKMA_TIME  (1.0/(0.04888*(1e-12)))

#endif
